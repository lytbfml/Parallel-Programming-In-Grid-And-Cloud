import java.io.Serializable;
import java.util.ArrayList;
import java.util.*;
import java.io.*;
import scala.*;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.broadcast.*;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.Function2;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.SparkConf;
import java.lang.*;
import java.util.Random;
import org.apache.spark.api.java.function.PairFunction;
import org.apache.spark.api.java.function.Function;
public class ACOSpark {

    public static final int ITERATIONS = 1000;
    public static final int NUMBEROFANTS = 18;
    public static final int NUMBEROFCITIES = 36;

    public static final double ALPHA = 0.5;
    public static final double BETA  = 0.8;
    public static final double Q     = 1000;
    public static final double RO    = 0.2;
    public static final int    TAUMAX = 2;
    public static final int    INITIALCITY = 0; //source
    private static Randoms randoms;
    public static double [][] CITIES; // CITIES[i][j] stands for the distance between city i and city j
    public static double [][] PHEROMONES;// Pheromones on every edge.
    public static double [][] DELTAPHEROMONES;
    public static int [][] GRAPH;
    public static int [][] ROUTES;
    public static int[] bestRoutes;
    public static double bestDistance;
  
    //Ant class, represent each ant, each ant will be forming its own route.
    private static class Ant implements Serializable {
        int[] routes;
        double distance;
        int antNumber;

        public Ant(int antNumber){
            this.routes = new int[NUMBEROFCITIES];
            this.distance = 0.0;
            this.antNumber = antNumber;
        };
    }

    //used to initialize CITIES. 
    public static void setCITYPOSITION(int city, double x, double y) {
        CITIES[city][0] = x;
        CITIES[city][1] = y;
    }

    //calculate distance between two cities for given x, y coordinates.
    private static double distance(int cityi, int cityj, double[][] cities) {
	 return Math.sqrt(Math.pow(cities[cityi][0] - cities[cityj][0], 2)
                + Math.pow(cities[cityi][1] - cities[cityj][1], 2));
    }

    //calculate total distance for given route. 
    private static double length(int route[], double[][] cities) {
        double sum = 0.0;
        for (int j = 0; j < NUMBEROFCITIES; j++) {
            if (j == NUMBEROFCITIES - 1) {
                sum += distance(route[j], route[0], cities);
            } else {
                sum += distance(route[j], route[j + 1], cities);
            }
        }
        return sum;
    }

    //initialize Pheromones 
    public static void connectCITIES(int cityi, int cityj) {
        GRAPH[cityi][cityj] = 1;
        PHEROMONES[cityi][cityj] = randoms.Uniforme() * TAUMAX; // init random pheromones
        //PHEROMONES[cityi][cityj] = 1;
	GRAPH[cityj][cityi] = 1;
        PHEROMONES[cityj][cityi] = PHEROMONES[cityi][cityj];
    }

    //check if a city has been visited.
    public static boolean visited(int[] nums, int c){
        for(int i = 0; i < nums.length; i++){
            if(nums[i] == c){
                return true;
            }
        }
        return false;
    }

    //update Pheromones with given distance of all ants. 
    private static void updatePHEROMONES(double[] currentLength) {
        for (int k = 0; k < NUMBEROFANTS; k++) {
            double rlength = currentLength[k]; // current path length for antk
            for (int r = 0; r < NUMBEROFCITIES - 1; r++) {
                int cityi = ROUTES[k][r];
                int cityj = ROUTES[k][r + 1];
                DELTAPHEROMONES[cityi][cityj] += Q / rlength;
                DELTAPHEROMONES[cityj][cityi] += Q / rlength;
            }
        }
        for (int i = 0; i < NUMBEROFCITIES; i++) {
            for (int j = 0; j < NUMBEROFCITIES; j++) {
                PHEROMONES[i][j] = (1 - RO) * PHEROMONES[i][j] + DELTAPHEROMONES[i][j];
                DELTAPHEROMONES[i][j] = 0.0;
            }
        }
    }

    public static void main(String[] args) {
        //first, create ant 
        List<Ant> temp = new ArrayList<Ant>();
        SparkConf conf = new SparkConf().setAppName("Ant Colony TSP");
        JavaSparkContext jsc = new JavaSparkContext(conf);
	    for(int j = 0; j < NUMBEROFANTS; j++) {
            temp.add(new Ant(j));
        }
        // use parallellize to create RDD. 
        JavaRDD <Ant> network = jsc.parallelize(temp);
        long startTime = System.currentTimeMillis();
        randoms = new Randoms(21);
	    // initialize matrices. 
        GRAPH = new int[NUMBEROFCITIES][];
        CITIES = new double[NUMBEROFCITIES][];
        PHEROMONES = new double[NUMBEROFCITIES][];
        DELTAPHEROMONES = new double[NUMBEROFCITIES][];

        for (int i = 0; i < NUMBEROFCITIES; i++) {
            GRAPH[i] = new int[NUMBEROFCITIES];
            PHEROMONES[i] = new double[NUMBEROFCITIES];
            DELTAPHEROMONES[i] = new double[NUMBEROFCITIES];
            CITIES[i] = new double[2];
            for (int j = 0; j < 2; j++) {
                CITIES[i][j] = -1.0;
            }
            for (int j = 0; j < NUMBEROFCITIES; j++) {
                 GRAPH[i][j] = 0;
                PHEROMONES[i][j] = 0.0;
                DELTAPHEROMONES[i][j] = 0.0;
            }
        }
        ROUTES = new int[NUMBEROFCITIES][];
        for (int i = 0; i < NUMBEROFANTS; i++) {
            ROUTES[i] = new int[NUMBEROFCITIES];
            for (int j = 0; j < NUMBEROFCITIES; j++) {
                ROUTES[i][j] = -1;
            }
        }
        //read city file and initailize graph and Pheromones. 
        try {
            File file = new File("cities.txt");

            BufferedReader bf = new BufferedReader(new FileReader(file));

            String line;
            int x = 0;
            while ((line = bf.readLine()) != null) {
                String[] words = line.split("\t");
                System.out.println(words);
                setCITYPOSITION(x, Integer.parseInt(words[1]), Integer.parseInt(words[2]));
                for (int j = 0; j < NUMBEROFCITIES; j++ ){
                    if (x == j) continue;
                    connectCITIES(x, j);
                }
                x++;
            }
        }catch (FileNotFoundException e) {
            e.printStackTrace();
        }catch (IOException e) {
            e.printStackTrace();
        }        

        
	    JavaPairRDD<java.lang.Double,Ant> pnetwork = null;
        int iterations = 0;
        while (iterations < ITERATIONS) { 
            iterations++;
            //broadcast CITIES because distance function needs it. 
            //broadcast Pheromones because it is needed to look for new route obviously. 
            Broadcast<double[][]> broadcastVar1 = jsc.broadcast(CITIES);    
            Broadcast<double[][]> broadcastVar = jsc.broadcast(PHEROMONES);
            //In the first transformation, let each ant look for a new route, store the disance as key, update the original 
            //ant class with new distance and route and use it as value.

		    pnetwork = network.mapToPair(new PairFunction<Ant,java.lang.Double , Ant>() { 
		    @Override
            public Tuple2 <java.lang.Double, Ant > call(Ant v) {
                int[] route = new int[NUMBEROFCITIES];
            	double alpha = 0.5;
			    double beta = 0.8;   
		        Randoms randoms = new Randoms(21); 
		        Ant result = v;
                double [][] PROBS = new double[37][];

                for (int i = 0; i < NUMBEROFCITIES; i++) {
                    PROBS[i] = new double[2];
                    for (int j = 0; j < 2; j++) {
                        PROBS[i][j] = -1.0;
                    }
                }
                //See sequential version for details on the optimization. 
                route[0] = 0;
                for (int i = 0; i < NUMBEROFCITIES - 1; i++) {
                    int cityi = route[i];
                    int count = 0;
                    for (int c = 0; c < NUMBEROFCITIES; c++) {
                        if (cityi == c) {
                            continue;
                        }
                        if (!visited(route, c)) {
                            double ETAij = Math.pow(1 / distance(cityi, c, broadcastVar1.value()), beta);
                            double TAUij = Math.pow((broadcastVar.value())[cityi][c], alpha);

                            double sum = 0.0;
                            for (int d = 0; d < NUMBEROFCITIES; d++) {
                                if (!visited(route, d)) {
                                    double ETA = Math.pow(1/distance(cityi, d, broadcastVar1.value()), beta);
                                    double TAU = Math.pow((broadcastVar.value())[cityi][d], alpha);
                                    sum += ETA * TAU;
                                }
                                            
                            }
                                       
                            PROBS[count][0] = (ETAij * TAUij) / sum;
                            PROBS[count][1] = (double) c;
                            count++;
                        }
                    }
                    double xi = randoms.Uniforme();
                    int y = 0;
                    double sum1 = PROBS[y][0];
                    while (sum < xi) {
                        y++;
                        sum += PROBS[y][0];
                    }                      
                    route[i + 1] = (int) PROBS[y][1];
				
                }
                //update route and distance. 
                result.routes = route;
                result.antNumber = v.antNumber;
                result.distance = length(route, broadcastVar1.value());
                return new Tuple2(result.distance, result);      

                }

            });
            //sort by key, the ant with shortest distance will be at 0 index.
            pnetwork = pnetwork.sortByKey();
            //optional: print intermediate result.
            System.out.println("distance is " + pnetwork.collect().get(0)._2().distance);
            //compare with current bestroute, update if necessary.
            if(pnetwork.collect().get(10)._2().distance < bestDistance){
                bestRoutes = pnetwork.collect().get(0)._2().routes;
                bestDistance = pnetwork.collect().get(0)._2().distance;
            }
            //store distance for all ants to pass in to updatePheromone, in the mean time, update Routes as well. 
            double[] allLengths = new double[NUMBEROFANTS];
            for(int i = 0; i < NUMBEROFANTS; i++ ){
                for(int j = 0; j < NUMBEROFANTS; j++){
                    if(pnetwork.collect().get(j)._2().antNumber == i){
                        allLengths[i] = pnetwork.collect.get(j)._2().distance;
                        ROUTES[i]= pnetwork.collect().get(j)._2().routes;
                    }
                }
                
            }
            //update Pheromonnes. 
            updatePHEROMONES(allLengths);
            //reset ants.:q
            pnetwork = pnetwork.mapValues(new Function<Ant, Ant>() {
                    // If a vertex’ new distance is shorter than prev, activate this vertex
                    // status and replace prev with the new distance.
                @Override
                public Ant call(Ant value) {
                    for(int i = 0; i < NUMBEROFCITIES; i++){
                        value.routes[i] = -1;
                    }
                    value.distance = 0.0;
                   return value;	
		        }            
            });  

           
        }
        //Print result;
        System.out.println("best distance is " + distance);

    }


}
