package edu.uwb.css534;


import edu.uw.bothell.css.dsl.MASS.Place;

/**
 * Created by liyangde on Dec, 2018
 */
public class City extends Place {
    public City(Object o) {

    }
}
