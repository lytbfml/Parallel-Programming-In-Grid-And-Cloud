package edu.uwb.css534;


import edu.uw.bothell.css.dsl.MASS.Agents;
import edu.uw.bothell.css.dsl.MASS.MASS;
import edu.uw.bothell.css.dsl.MASS.Places;
import edu.uw.bothell.css.dsl.MASS.logging.LogLevel;

import java.io.*;
import java.util.Arrays;

/**
 * Created by liyangde on Dec, 2018
 */
public class ACO_Mass {
    public static int ITERATIONS = 1000;
    public static int NUMBEROFANTS = 8;
    public static final int NUMBEROFCITIES = 37;

    public static final double ALPHA = 0.5;
    public static final double BETA  = 0.8;
    public static final double Q     = 1000;
    public static final double RO    = 0.5;
    public static final int    TAUMAX = 2;
    public static final int    INITIALCITY = 0; //source

    private static final String NODE_FILE = "nodes.xml";



    public static void main(String[] args) {
        MASS.setNodeFilePath(NODE_FILE);
        MASS.setLoggingLevel(LogLevel.ERROR);
        ITERATIONS = Integer.parseInt(args[1]);
        NUMBEROFANTS = Integer.parseInt(args[2]);
        MASS.init();
        long start = System.currentTimeMillis();
        Places places = new Places(1, City.class.getName(), null, NUMBEROFCITIES);
        Agents ants = new Agents(1, ACO.class.getName(), null, places, NUMBEROFANTS);

        //System.out.println("111111");
        ants.callAll(ACO.INIT);

        // read from file
        try {

            File file = new File(args[0]);

            BufferedReader bf = new BufferedReader(new FileReader(file));

            String line;
            int i = 0;
            while ((line = bf.readLine()) != null) {
                String[] words = line.split("\t");
                //Object arg = Arrays.asList(i,Integer.parseInt(words[1]),Integer.parseInt(words[2])).toArray();
                DataPOJO data = DataPOJO.build(i,Integer.parseInt(words[1]),Integer.parseInt(words[2]));
                ants.callAll(ACO.SET_POSITION, data);
                for (int j = 0; j < NUMBEROFCITIES; j++ ){
                    if (i == j) continue;
                    ants.callAll(ACO.CONNECT, (Object) Arrays.asList(i,j).toArray());
                }
                i++;
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }catch (IOException e) {
            e.printStackTrace();
        }

        for (int i = 0; i < ITERATIONS; i++) {
            // let ants go
            ants.callAll(ACO.OPTIMIZE);
        }

        ACO.printRESULTS();
        long end = System.currentTimeMillis();
        System.out.println("Elapsed time: "+ (end - start)+" ms");
        MASS.finish();

    }
}
