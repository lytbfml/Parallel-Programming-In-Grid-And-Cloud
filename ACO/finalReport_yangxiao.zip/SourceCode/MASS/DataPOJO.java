package edu.uwb.css534;

import java.io.IOException;
import java.io.Serializable;

/**
 * Created by liyangde on Dec, 2018
 */
public class DataPOJO implements Serializable {
    private static final long serialVersionUID = 7526472295622776147L;
    private int[] cities;
    private double position[];

    public static DataPOJO build(int city, int x, int y){
        return new DataPOJO().setCities(new int[]{city,x, y});
    }
    public int[] getCities() {
        return cities;
    }

    public DataPOJO setCities(int[] cities) {
        this.cities = cities;
        return this;
    }

    public double[] getPosition() {
        return position;
    }

    public void setPosition(double[] position) {
        this.position = position;
    }
}
