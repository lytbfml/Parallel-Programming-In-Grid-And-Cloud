/**
 * Created by liyangde on Dec, 2018
 */
import mpi.*;

import java.io.*;
import java.io.File;

public class MainMpi {
    public static final int ITERATIONS = 3000;
    public static final int NUMBEROFANTS = 8;
    public static final int NUMBEROFCITIES = 37;

    public static final double ALPHA = 0.5;
    public static final double BETA  = 1.0;
    public static final double Q     = 1000;
    public static final double RO    = 0.5;
    public static final int    TAUMAX = 2;
    public static final int    INITIALCITY = 0; //source
    private static ACOMpi ants;
    public static void main(String[] args) throws MPIException{
        MPI.Init(args);
//        int my_rank = MPI.COMM_WORLD.Rank();
//        int size = MPI.COMM_WORLD.Size();
//
//        ants = new ACOMpi(NUMBEROFANTS, NUMBEROFCITIES, ALPHA, BETA, Q, RO, TAUMAX, INITIALCITY, my_rank, size);
//
//
//        ants.init();
//        try {
//
//            java.io.File file = new File("cities.txt");
//
//            BufferedReader bf = new BufferedReader(new FileReader(file));
//
//            String line;
//            int i = 0;
//            while ((line = bf.readLine()) != null) {
//                String[] words = line.split("\t");
//                ants.setCITYPOSITION(i, Integer.parseInt(words[1]), Integer.parseInt(words[2]));
//                for (int j = 0; j < NUMBEROFCITIES; j++ ){
//                    if (i == j) continue;
//                    ants.connectCITIES(i, j);
//                }
//                i++;
//            }
//        } catch (FileNotFoundException e) {
//            e.printStackTrace();
//        }catch (IOException e) {
//            e.printStackTrace();
//        }
//        long start = System.currentTimeMillis();
//        ants.optimize(ITERATIONS);
//        if (my_rank == 0) {
//            ants.printRESULTS();
//            long end = System.currentTimeMillis();
//            System.out.println("Elapsed time: "+ (end - start) + "ms");
//        }

        MPI.Finalize();
    }
}
